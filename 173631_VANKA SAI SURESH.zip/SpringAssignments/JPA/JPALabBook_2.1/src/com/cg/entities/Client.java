package com.cg.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Author author1=new Author();
		author1.setId(101);
		author1.setName("sumanth");
		
		Author author2=new Author();
		author2.setId(102);
		author2.setName("suresh");
		
		Author author3=new Author();
		author3.setId(103);
		author3.setName("kiran");
		
		Book book1=new Book();
		book1.setISBN(1);
		book1.setTitle("the book abc");
		book1.setPrice(100);
		
		book1.addAuthor(author1);
		book1.addAuthor(author2);
		book1.addAuthor(author3);
		
		Book book2=new Book();
		book2.setISBN(2);
		book2.setTitle("the book xyz");
		book2.setPrice(130.20);
		
		book2.addAuthor(author1);
		book2.addAuthor(author2);
		book2.addAuthor(author3);
		
		Book book3=new Book();
		book3.setISBN(3);
		book3.setTitle("the book big data");
		book3.setPrice(150.60);
		
		book3.addAuthor(author1);
		book3.addAuthor(author2);
		book3.addAuthor(author3);
		
		em.persist(book1);
		em.persist(book2);
		em.persist(book3);
		System.out.println("Added books along with author details to database.");

		em.getTransaction().commit();
		em.close();
		factory.close();
	

	}

}
