package com.cg.exception;

public class TraineeException extends Exception{
	public  TraineeException(String msg) {
		super(msg);
	}
}
