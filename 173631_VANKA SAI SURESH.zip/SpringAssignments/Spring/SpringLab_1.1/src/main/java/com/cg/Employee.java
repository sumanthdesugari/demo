package com.cg;

public class Employee {

	
	int employeeid;
	String ename;
	double salary;
	String businessunit;
	int age;
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBusinessunit() {
		return businessunit;
	}
	public void setBusinessunit(String businessunit) {
		this.businessunit = businessunit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", ename=" + ename + ", salary=" + salary + ", businessunit="
				+ businessunit + ", age=" + age + "]";
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
