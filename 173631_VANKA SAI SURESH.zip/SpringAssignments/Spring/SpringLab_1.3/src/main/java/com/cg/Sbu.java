package com.cg;

import java.util.List;

public class Sbu {

	
	int sbucode;
	String sbuname;
	String sbuhead;
	List<Employee> elist;
	private Employee employee;
	
	
	
	public Sbu(Employee employee) {
		// TODO Auto-generated constructor stub
		this.employee=employee;
	}
	public int getSbucode() {
		return sbucode;
	}
	public void setSbucode(int sbucode) {
		this.sbucode = sbucode;
	}
	public String getSbuname() {
		return sbuname;
	}
	public void setSbuname(String sbuname) {
		this.sbuname = sbuname;
	}
	public String getSbuhead() {
		return sbuhead;
	}
	public void setSbuhead(String sbuhead) {
		this.sbuhead = sbuhead;
	}
	public List<Employee> getElist() {
		return elist;
	}
	public void setElist(List<Employee> elist) {
		this.elist = elist;
	}
	
	@Override
	public String toString() {
		return "Sbudetails [sbucode=" + sbucode + ", sbuname=" + sbuname + ", sbuhead=" + sbuhead + ", elist=" + elist
				+"]";
	}
	
}
