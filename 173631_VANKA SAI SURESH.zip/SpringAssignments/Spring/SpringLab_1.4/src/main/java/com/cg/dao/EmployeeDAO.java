package com.cg.dao;

public interface EmployeeDAO {

	public void getEmpById(int choice);
}
