package com.cg.Client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Service.EmployeeService;
import com.cg.Service.EmployeeServiveImpl;

public class MainUI {

	public static void main(String[] args) {
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		EmployeeServiveImpl es= (EmployeeServiveImpl) context.getBean("eserve");
		
		
		System.out.println("enter the id from the following : 1: 100 \n 2.101 \n 3.102");
		Scanner scanner=new Scanner(System.in);
		int choice=scanner.nextInt();
		es.getEmpById(choice);
	}

}
