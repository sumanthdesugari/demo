package com.cg.Service;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.EmployeeDAOImpl;

public class EmployeeServiveImpl implements EmployeeService {

	EmployeeDAOImpl dao;
	public EmployeeServiveImpl(EmployeeDAOImpl dao) {
		this.dao=dao;
	}
	
	
	public void getEmpById(int choice) {
		dao.getEmpById(choice);

	}

}
