package com.cg.Service;

public interface EmployeeService {
	public void getEmpById(int choice);
}
