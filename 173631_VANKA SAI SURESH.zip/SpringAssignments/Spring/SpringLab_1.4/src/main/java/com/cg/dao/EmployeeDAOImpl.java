package com.cg.dao;

import java.util.Map;

import com.cg.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	
	Map<Integer,Employee>map;
	public void getEmpById(int choice) {
		
		switch(choice) {
		case 1:
		System.out.println(map.get(100));break;
		case 2: System.out.println(map.get(101));break;
		case 3: System.out.println(map.get(102));break;
		default:System.out.println("Wrong choice!!");
		}
		

	}
	public Map<Integer, Employee> getMap() {
		return map;
	}
	public void setMap(Map<Integer, Employee> map) {
		this.map = map;
	}

}
