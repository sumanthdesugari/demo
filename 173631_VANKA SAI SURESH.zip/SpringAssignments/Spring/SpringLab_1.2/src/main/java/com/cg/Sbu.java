package com.cg;

public class Sbu {

	
	int sbuid=201;
	String sbuname="kittu";
	String sbuhead="Tester";
	public int getSbuid() {
		return sbuid;
	}
	public void setSbuid(int sbuid) {
		this.sbuid = sbuid;
	}
	public String getSbuname() {
		return sbuname;
	}
	public void setSbuname(String sbuname) {
		this.sbuname = sbuname;
	}
	public String getSbuhead() {
		return sbuhead;
	}
	public void setSbuhead(String sbuhead) {
		this.sbuhead = sbuhead;
	}
	@Override
	public String toString() {
		return "Sbu [sbuid=" + sbuid + ", sbuname=" + sbuname + ", sbuhead=" + sbuhead + "]";
	}
	public void sbudetails() {
		getSbuname();
		getSbuid();
		getSbuhead();
	}
}
