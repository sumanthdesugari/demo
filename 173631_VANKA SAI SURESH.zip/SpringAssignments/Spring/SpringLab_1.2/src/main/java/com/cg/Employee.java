package com.cg;

public class Employee {

	
	int eid=101;
	String ename="suresh";
	String bunit="FS Developer";
	double salary=20000.0;
	private Sbu sbu;
	
	public Employee(Sbu sbu) {
		// TODO Auto-generated constructor stub
		this.sbu=sbu;
	}
	public void Sbudetails() {
		sbu.sbudetails();
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", bunit=" + bunit + ", salary=" + salary + ", sbu=" + sbu
				+ "]";
	}
	
}
